import './App.css';
import LoginForm from './LoginForm';


function App() {
  return (
    <div class="mainPage">
      <LoginForm />
    </div>
  );
}

export default App;